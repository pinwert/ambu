/*
  AmbuComm.cpp - Library for communicating with AmbuApp
  Created by Enrique Piña Monserrat, March 28, 2020
  Released into the public domain.
*/

#include "Arduino.h"
#include "AmbuComm.h"

AmbuComm::AmbuComm()
{
}

AmbuComm::setup(int baudios)
{
    Serial.begin(baudios);
}

void AmbuComm::send(float pressure, float volume, float ie, float frequency)
{
    Serial.print(pressure);
    Serial.print(",");
    Serial.print(volume);
    Serial.print(",");
    Serial.print(ie);
    Serial.print(",");
    Serial.print(frequency);
    Serial.flush();
}